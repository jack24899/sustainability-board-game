package sustainabilityBoardGame;

public class EfficiencyCalculator {
	
	public static int calculateEfficiencyScore(Player player, GameBoard board) {
        int totalResourceValue = player.getResources();
        
        // Add value of developments
        for (PropertySquare property : board.getPlayerProperties(player)) {
            totalResourceValue += property.getTotalInvestment();
        }
        
        int totalSpent = player.getTotalSpent();
        
        // Calculate efficiency: what percentage of resources have been invested in sustainable projects
        int efficiency = (totalSpent > 0) ? (totalResourceValue * 100) / (totalSpent + totalResourceValue) : 0;
        
        return efficiency;
    }

}
