package sustainabilityBoardGame;

public class GameState {

	private boolean gameRunning;

	public boolean isGameRunning() {
		return gameRunning;
	}

	public void setGameRunning(boolean gameRunning) {
		this.gameRunning = gameRunning;
	}

}
