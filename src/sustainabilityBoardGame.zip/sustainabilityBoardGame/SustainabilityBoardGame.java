package sustainabilityBoardGame;



import java.util.List;
import java.util.Scanner;

public class SustainabilityBoardGame {
	 private GameBoard board;
	    private PlayerManager playerManager;
	    private GameState gameState;
	    private UserInterface ui;
	    private Scanner scanner;
	    
	    public static void main(String[] args) {
	        SustainabilityBoardGame game = new SustainabilityBoardGame();
	        game.initialize();
	        game.play();
	    }
	    
	    public SustainabilityBoardGame() {
	        this.scanner = new Scanner(System.in);
	        this.ui = new UserInterface(scanner);
	    }
	    
	    private void initialize() {
	        ui.displayWelcomeMessage();
	        
	        board = new GameBoard();
	        playerManager = new PlayerManager(ui);
	        gameState = new GameState();
	        
	        playerManager.initializePlayers(GameConfig.INITIAL_RESOURCES);
	        gameState.setGameRunning(true);
	    }
	    
	    private void play() {
	        while (gameState.isGameRunning()) {
	            Player currentPlayer = playerManager.getCurrentPlayer();
	            
	            // Skip player if they are in wasteland
	            if (currentPlayer.isInWasteland()) {
	                ui.displayWastelandSkipMessage(currentPlayer);
	                currentPlayer.leaveWasteland();
	                playerManager.nextPlayer();
	                continue;
	            }
	            
	            ui.displayGameStatus(board, playerManager.getPlayers());
	            
	            if (!handlePlayerTurn(currentPlayer)) {
	                break; // Player wants to quit
	            }
	            
	            checkGameEndConditions();
	            if (gameState.isGameRunning()) {
	                playerManager.nextPlayer();
	            }
	        }
	        
	        // Game has ended, show final results
	        ui.displayFinalResults(playerManager.getPlayers(), board);
	    }
	    
	    private boolean handlePlayerTurn(Player player) {
	        ui.displayPlayerTurn(player);
	        
	        List<PropertySquare> ownedProperties = board.getPlayerProperties(player);
	        boolean canDevelopAny = PropertyUtils.canDevelopAny(ownedProperties);
	        
	        int choice = ui.getPlayerTurnChoice(canDevelopAny);
	        
	        switch (choice) {
	            case 1:
	                handleDiceRollAndMove(player);
	                return true;
	            case 2:
	                if (canDevelopAny) {
	                    PropertyDevelopmentHandler.developProperty(player, ownedProperties, ui);
	                } else {
	                    ui.displayQuitMessage(player);
	                    gameState.setGameRunning(false);
	                }
	                return true;
	            case 3:
	                if (canDevelopAny) {
	                    ui.displayQuitMessage(player);
	                    gameState.setGameRunning(false);
	                }
	                return true;
	            default:
	                return true;
	        }
	    }
	    
	    private void handleDiceRollAndMove(Player player) {
	    	int grantAmount;
	        DiceRoll diceRoll = new DiceRoll();
	        ui.displayDiceRoll(player, diceRoll);
	        
	        int oldPosition = player.getPosition();
	        int newPosition = (oldPosition + diceRoll.getTotal()) % GameConfig.TOTAL_SQUARES;
	        
	        // Check if player passes GO
	        if (newPosition < oldPosition) {
	            int efficiency = EfficiencyCalculator.calculateEfficiencyScore(player, board);
	            if (efficiency == 0) {
	            	grantAmount = 100; //  handles grant amount if landed on before a player has bought a property (hence they will have 0 efficiency score)
	            } else {
	            	grantAmount = 100 + ((efficiency + 1) * 5); // Base amount plus bonus based on efficiency
	            }
	            
	            
	            ui.displayPassedGo(player, efficiency, grantAmount);
	            player.addResources(grantAmount, "Sustainability Grant");
	        }
	        
	        player.setPosition(newPosition);
	        ui.displayPlayerMovement(player, board.getSquareAt(newPosition));
	        
	        // Handle the square the player landed on
	        SquareActionHandler.handleSquareAction(player, board.getSquareAt(newPosition), board, playerManager, ui);
	    }
	    
	    private void checkGameEndConditions() {
	        int playersWithResources = 0;
	        
	        for (Player player : playerManager.getPlayers()) {
	            if (player.getResources() > 0) {
	                playersWithResources++;
	            }
	        }
	        
	        if (playersWithResources <= 1) {
	            ui.displayGameOver();
	            gameState.setGameRunning(false);
	        }
	    }

}
