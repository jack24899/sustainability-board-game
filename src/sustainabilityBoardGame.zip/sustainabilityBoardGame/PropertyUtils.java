package sustainabilityBoardGame;

import java.util.List;

public class PropertyUtils {
	
	 public static boolean canDevelopAny(List<PropertySquare> properties) {
	        for (PropertySquare property : properties) {
	            if (property.canBeDeveloped()) {
	                return true;
	            }
	        }
	        return false;
	    }

}
