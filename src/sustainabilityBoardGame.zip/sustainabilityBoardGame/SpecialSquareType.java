package sustainabilityBoardGame;

public enum SpecialSquareType {

	GO, WASTELAND;
}
