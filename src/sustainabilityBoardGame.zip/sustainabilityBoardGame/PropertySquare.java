package sustainabilityBoardGame;

public class PropertySquare extends BoardSquare {
	private int purchaseCost;
    private PropertyType type;
    private Player owner;
    private int developmentLevel;
    private int totalInvestment;
    
    public PropertySquare(String name, int purchaseCost, PropertyType type) {
        super(name);
        this.purchaseCost = purchaseCost;
        this.type = type;
        
        this.owner = null;
        this.developmentLevel = 0;
        this.totalInvestment = 0;
    }
    
    public int getPurchaseCost() {
        return purchaseCost;
    }
    
    public PropertyType getType() {
        return type;
    }
    
    
    public Player getOwner() {
        return owner;
    }
    
    public void setOwner(Player owner) {
        this.owner = owner;
        this.totalInvestment += purchaseCost;
    }
    
    public int getDevelopmentLevel() {
        return developmentLevel;
    }
    
    public boolean canBeDeveloped() {
        int maxDevelopmentLevel;
        
        switch (type) {
            case WASTE_MANAGEMENT:
            case ECO_CITY:
                maxDevelopmentLevel = 2;
                break;
            case MARINE_ENERGY:
            case LAND_ENERGY:
                maxDevelopmentLevel = 3;
                break;
            default:
                maxDevelopmentLevel = 0;
        }
        
        return developmentLevel < maxDevelopmentLevel;
    }
    
    public int getDevelopmentCost() {
        double multiplier;
        
        switch (developmentLevel) {
            case 0:
                multiplier = 1.5;
                break;
            case 1:
                multiplier = 2.0;
                break;
            case 2:
                multiplier = (type == PropertyType.MARINE_ENERGY || type == PropertyType.LAND_ENERGY) ? 3.0 : 2.0;
                break;
            default:
                multiplier = 1.0;
        }
        
        return (int)(purchaseCost * multiplier);
    }
    
    public void develop() {
        int cost = getDevelopmentCost();
        developmentLevel++;
        totalInvestment += cost;
    }
    
    public int getRent() {
        double rentMultiplier;
        
        switch (developmentLevel) {
            case 0:
                rentMultiplier = 0.2;
                break;
            case 1:
                rentMultiplier = 0.5;
                break;
            case 2:
                rentMultiplier = 1.0;
                break;
            case 3:
                rentMultiplier = 1.5;
                break;
            default:
                rentMultiplier = 0.1;
        }
        
        // Eco City has special rent rules for final development
        if (type == PropertyType.ECO_CITY && developmentLevel == 2) {
            return (int)(purchaseCost * 2.0);
        }
        
        return (int)(purchaseCost * rentMultiplier);
    }
    
    public int getTotalInvestment() {
        return totalInvestment;
    }
    
    public String getCurrentDevelopmentName() {
        switch (type) {
            case WASTE_MANAGEMENT:
                switch (developmentLevel) {
                    case 0: return "Composting Plant";
                    case 1: return "Incineration Plant";
                    case 2: return "Advanced Waste Management";
                    default: return "Waste Management Plant";
                }
            case MARINE_ENERGY:
                switch (developmentLevel) {
                    case 0: return "Tidal Wave Plant";
                    case 1: return "Offshore Wind Farm";
                    case 2: return "Wave Power System";
                    case 3: return "Integrated Marine Energy Hub";
                    default: return "Marine Renewable Energy Plant";
                }
            case LAND_ENERGY:
                switch (developmentLevel) {
                    case 0: return "Solar Farm";
                    case 1: return "Biomass Energy Plant";
                    case 2: return "Nuclear Power Plant";
                    case 3: return "Smart Grid System";
                    default: return "Land Based Renewable Energy Plant";
                }
            case ECO_CITY:
                switch (developmentLevel) {
                    case 0: return "Eco Housing";
                    case 1: return "Sustainable Transport Network";
                    case 2: return "Fully Integrated Smart City";
                    default: return "Eco City";
                }
            default:
                return getName();
        }
    }

}
