package sustainabilityBoardGame;

import java.util.ArrayList;
import java.util.List;

public class PlayerManager {
	
	private List<Player> players;
    private int currentPlayerIndex;
    private UserInterface ui;
    
    public PlayerManager(UserInterface ui) {
        this.players = new ArrayList<>();
        this.currentPlayerIndex = 0;
        this.ui = ui;
    }
    
    public void initializePlayers(int initialResources) {
        int numPlayers = ui.getValidPlayerCount(GameConfig.MIN_PLAYERS, GameConfig.MAX_PLAYERS);
        
        List<String> playerNames = ui.getPlayerNames(numPlayers);
        
        for (String name : playerNames) {
            players.add(new Player(name, initialResources));
        }
    }
    
    public Player getCurrentPlayer() {
        return players.get(currentPlayerIndex);
    }
    
    public void nextPlayer() {
        currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
    }
    
    public List<Player> getPlayers() {
        return players;
    }
    
    public void distributeResources(Player player) {
        int resourcesAmount = player.getResources() / 4; // 25% of resources
        int resourcesPerPlayer = resourcesAmount / (players.size() - 1);
        
        ui.displayResourceDistribution(player, resourcesAmount);
        
        player.removeResources(resourcesAmount, "Resource distribution");
        
        for (Player recipient : players) {
            if (recipient != player) {
                recipient.addResources(resourcesPerPlayer, "Distribution from " + player.getName());
                ui.displayResourceReceived(recipient, resourcesPerPlayer);
            }
        }
    }
    
    public double getAverageResourcesExcludingPlayer(Player excludedPlayer) {
        int totalResources = 0;
        int playerCount = 0;
        
        for (Player player : players) {
            if (player != excludedPlayer) {
                totalResources += player.getResources();
                playerCount++;
            }
        }
        
        return (playerCount > 0) ? totalResources / (double) playerCount : 0;
    }

}
