package sustainabilityBoardGame;

import java.util.Random;

public class DiceRoll {
	
	private int dice1;
    private int dice2;
    private static final Random random = new Random();
    
    public DiceRoll() {
        this.dice1 = random.nextInt(6) + 1;
        this.dice2 = random.nextInt(6) + 1;
    }
    
    public int getDice1() {
        return dice1;
    }
    
    public int getDice2() {
        return dice2;
    }
    
    public int getTotal() {
        return dice1 + dice2;
    }

}
