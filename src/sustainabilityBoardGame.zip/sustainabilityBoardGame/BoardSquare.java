package sustainabilityBoardGame;

public abstract class BoardSquare {

	 private String name;
	    
	    public BoardSquare(String name) {
	        this.name = name;
	    }
	    
	    public String getName() {
	        return name;
	    }
}
