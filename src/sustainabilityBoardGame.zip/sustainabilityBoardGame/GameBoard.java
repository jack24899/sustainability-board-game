package sustainabilityBoardGame;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GameBoard {

private List<BoardSquare> squares;
    
    public GameBoard() {
        this.squares = new ArrayList<>();
        initializeBoard();
    }
    
    private void initializeBoard() {
        // Create the board with appropriate fields
        squares.add(new SpecialSquare("Sustainability Grant", SpecialSquareType.GO));
        squares.add(new PropertySquare("Waste Management Plant", 200, PropertyType.WASTE_MANAGEMENT));
        squares.add(new PropertySquare("Marine Renewable Energy Plant", 300, PropertyType.MARINE_ENERGY));
        squares.add(new SpecialSquare("Wasteland", SpecialSquareType.WASTELAND));
        squares.add(new PropertySquare("Land Based Renewable Energy Plant", 350, PropertyType.LAND_ENERGY));
        squares.add(new PropertySquare("Eco City", 400, PropertyType.ECO_CITY));
    }
    
    public BoardSquare getSquareAt(int position) {
        return squares.get(position);
    }
    
    public List<BoardSquare> getAllSquares() {
        return squares;
    }
    
    public List<PropertySquare> getPlayerProperties(Player player) {
        List<PropertySquare> properties = new ArrayList<>();
        
        for (BoardSquare square : squares) {
            if (square instanceof PropertySquare) {
                PropertySquare property = (PropertySquare) square;
                if (property.getOwner() == player) {
                    properties.add(property);
                }
            }
        }
        
        return properties;
    }
    
    public List<PropertySquare> getPlayerDevelopableProperties(Player player) {
        List<PropertySquare> developableProperties = new ArrayList<>();
        Map<PropertyType, List<PropertySquare>> propertiesByType = new HashMap<>();
        
        // Group properties by type
        for (BoardSquare square : squares) {
            if (square instanceof PropertySquare) {
                PropertySquare property = (PropertySquare) square;
                if (property.getOwner() == player) {
                    PropertyType type = property.getType();
                    if (!propertiesByType.containsKey(type)) {
                        propertiesByType.put(type, new ArrayList<>());
                    }
                    propertiesByType.get(type).add(property);
                }
            }
        }
        
        // Check which property types the player owns completely
        for (Map.Entry<PropertyType, List<PropertySquare>> entry : propertiesByType.entrySet()) {
            PropertyType type = entry.getKey();
            List<PropertySquare> properties = entry.getValue();
            
            int requiredProperties = getRequiredPropertiesForType(type);
            
            if (properties.size() == requiredProperties) {
                // Player owns all properties in this field
                for (PropertySquare property : properties) {
                    if (property.canBeDeveloped()) {
                        developableProperties.add(property);
                    }
                }
            }
        }
        
        return developableProperties;
    }
    
    private int getRequiredPropertiesForType(PropertyType type) {
        switch (type) {
            case WASTE_MANAGEMENT:
            case ECO_CITY:
                return 2;
            case MARINE_ENERGY:
            case LAND_ENERGY:
                return 3;
            default:
                return 0;
        }
    }
}
