package sustainabilityBoardGame;

public class Player {
	
	private String name;
    private int resources;
    private int position;
    private int totalSpent;
    private boolean inWasteland;
    private boolean hasRecentlyHadWastelandChoice;
    
    public Player(String name, int initialResources) {
        this.name = name;
        this.resources = initialResources;
        this.position = 0;
        this.totalSpent = 0;
        this.inWasteland = false;
        this.hasRecentlyHadWastelandChoice = false;
    }
    
    public String getName() {
        return name;
    }
    
    public int getResources() {
        return resources;
    }
    
    public void addResources(int amount, String reason) {
        resources += amount;
        System.out.println(name + " received " + amount + " resources (" + reason + ")");
        System.out.println("New balance: " + resources);
    }
    
    public void removeResources(int amount, String reason) {
        resources -= amount;
        totalSpent += amount;
        System.out.println(name + " spent " + amount + " resources (" + reason + ")");
        System.out.println("New balance: " + resources);
    }
    
    public int getPosition() {
        return position;
    }
    
    public void setPosition(int position) {
        this.position = position;
    }
    
    public int getTotalSpent() {
        return totalSpent;
    }
    
    public boolean isInWasteland() {
        return inWasteland;
    }
    
    public void sendToWasteland() {
        inWasteland = true;
    }
    
    public void leaveWasteland() {
        inWasteland = false;
    }
    
    public boolean hasRecentlyHadWastelandChoice() {
        return hasRecentlyHadWastelandChoice;
    }
    
    public void setHasRecentlyHadWastelandChoice(boolean value) {
        hasRecentlyHadWastelandChoice = value;
    }
    
    public boolean isEligibleForWastelandChoice() {
        return resources > 0;
    }
    

	
}
