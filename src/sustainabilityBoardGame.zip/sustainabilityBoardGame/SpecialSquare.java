package sustainabilityBoardGame;

public class SpecialSquare extends BoardSquare{

private SpecialSquareType type;
    
    public SpecialSquare(String name, SpecialSquareType type) {
        super(name);
        this.type = type;
    }
    
    public SpecialSquareType getType() {
        return type;
    }
}
