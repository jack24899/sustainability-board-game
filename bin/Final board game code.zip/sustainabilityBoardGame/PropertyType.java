package sustainabilityBoardGame;

/**
 * Enum for the each type of purchasable field
 */
public enum PropertyType {
    
    WASTE_MANAGEMENT, MARINE_ENERGY, LAND_ENERGY, ECO_CITY;
}